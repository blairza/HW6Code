import java.util.AbstractMap;
import java.util.Map.Entry;
import java.util.ArrayList;
import java.util.List;

/**
 * Code originally came from Cornell University students for a databases course.
 * Code was edited by Amanda Stouder for style, testing, and homework problem
 * changes.
 * 
 */
public class BPlusTree<K extends Comparable<K>, T> {

	private Node<K, T> root;
	private int degree = 2;

	public BPlusTree(int degree) {
		this.degree = degree;
	}

	public Node<K, T> getRoot() {
		return root;
	}

	public int getDegree() {
		return this.degree;
	}

	/**
	 * Search the value for a specific key, and return the data at that key. You can
	 * think of the "Key" as the index field, and the data as the data pointer or
	 * row data that it returns (depending on the type of index).
	 * 
	 * This search should do an exact match search. If the key is found in the tree,
	 * it should return the value of that item. If not, it should return a null
	 * value.
	 * 
	 * @param key - The key to search for.
	 * @return value - The value of the item found. If key not found, null.
	 */
	public T exactMatchSearch(K key) {
		// TODO: Implement me second!
		Node keyNode = findLeafNode(root, key);
		if (keyNode == null) {
			return null;
		}
		if (keyNode.isLeafNode) {
			LeafNode temp = (LeafNode) keyNode;
			return exactMatchHelper(temp, key);
		} else {
			IndexNode temp = (IndexNode) keyNode;
			for (int i = 0; i < temp.getNumKeys(); i++) {
				if (temp.getKey(i) == key) {
					return (T) temp.getKey(i).toString();
				}
			}
			for (int i = 0; i < temp.getNumChildren(); i++) {
				if (temp.getChild(i).isLeafNode) {
					LeafNode temp2 = (LeafNode) temp.getChild(i);
					return (T) exactMatchHelper(temp2, key);
				}
			}
		}
		return null;
	}

	public T exactMatchHelper(Node node, K key) {
		if (node.isLeafNode) {
			LeafNode temp = (LeafNode) node;
			if (temp.findValue(key) == null) {
				while (temp.getNextLeaf() != null) {
					temp = temp.getNextLeaf();
					if (temp.findValue(key) != null) {
						return (T) temp.findValue(key);
					}
				}
			}
			return (T) temp.findValue(key);
		}
		return null;
	}

	/**
	 * Finds the leaf node where the given key should exist. Do NOT find the value
	 * itself here, just the leaf node where the value should exist. This is a
	 * helper method for the exactMatchSearch, as well as the
	 * greaterThanEqualToKeySearch and lessThanEqualToKeySearch.
	 * 
	 * Implement this method first. When implemented correctly, the delete tests
	 * will work, However, all tests with "hybrid" in the name and those and
	 * contained in "SearchTests" will still fail.
	 * 
	 * 
	 * 
	 * @param startingNode
	 * @param key
	 * @return
	 */
	private Node<K, T> findLeafNode(Node<K, T> startingNode, K key) {
		// TODO: Implement me first!
		if (startingNode == null) {
			return null;
		}
		if (startingNode.isLeafNode) {
			LeafNode temp = (LeafNode) startingNode;
			for (int i = 0; i < temp.getNumKeys(); i++) {
				if (temp.getKey(i) == key) {
					return temp;
				}
			}
		} else {
			IndexNode temp = (IndexNode) startingNode;
			for (int i = 0; i < temp.getNumChildren(); i++) {
				if (findLeafNode(temp.getChild(i), key) != null) {
					return temp.getChild(i);
				}
			}
		}
		return startingNode;
	}

	/**
	 * Performs a greater than or equal to range search on the B+ tree.
	 * 
	 * If the given key is found in the tree, it returns a list of values with that
	 * key value or greater. If the value is not found, it returns a list of all
	 * items with keys greater than the given key value. Returned items must be in
	 * ascending order by their key field.
	 * 
	 * @param key - The value to perform a >= search against.
	 * @return The values of the items that had a key >= to what was given.
	 */
	public List<T> greaterThanEqualToKeySearch(K key) {
		// TODO: Implement me after exactMatch is working!
		List<T> values = new ArrayList<T>();
		T value = exactMatchSearch(key);
		if (value != null) {
			values.add(value);
			Node start = root;
			if (start.isLeafNode) {
				LeafNode temp = (LeafNode) start;
				for (int i = 0; i < temp.getNumKeys(); i++) {
					if (temp.getKey(i).compareTo(value) >= 0) {
						values.add((T) temp.getKey(i));
					}
				}
				if (temp.getNextLeaf().isLeafNode) {
					values = leafHelper(temp.getNextLeaf(), values, value);
				}
			}
		} else {
			Node start = root;
			if (start.isLeafNode) {
				LeafNode temp = (LeafNode) start;
				for (int i = 0; i < temp.getNumKeys(); i++) {
					if (temp.getKey(i).compareTo(value) >= 0) {
						values.add((T) temp.getKey(i));
					}
				}
				if (temp.getNextLeaf().isLeafNode) {
					values = leafHelper(temp.getNextLeaf(), values, value);
				}
			} else {
				IndexNode temp = (IndexNode) start;
				for (int i = 0; i < temp.getNumKeys(); i++) {
					if (temp.getKey(i).compareTo(key) >= 0) {
						values.add((T) temp.getKey(i));
					}
				}
				for (int i = 0; i < temp.getNumChildren(); i++) {
					if (temp.getChild(i).isLeafNode) {
						values = leafHelper((LeafNode) temp.getChild(i), values, (T) key);
					} else {
						IndexNode temp2 = (IndexNode) temp.getChild(i);
						for (int j = 0; j < temp2.getNumKeys(); j++) {
							if (temp2.getKey(i).compareTo(key) >= 0) {
								values.add((T) temp2.getKey(i));
							}
						}
						if (temp2.getNumChildren() > 0) {
							values = indexHelper(temp2, values, key);
						}
					}
				}
			}
		}
		return values;
	}

	public List<T> leafHelper(LeafNode node, List<T> values, T value) {
		for (int i = 0; i < node.getNumKeys(); i++) {
			if (node.getKey(i).compareTo(value) >= 0) {
				values.add((T) node.getKey(i));
			}
		}
		if (node.getNextLeaf() != null) {
			if (node.getNextLeaf().isLeafNode) {
				values = leafHelper(node.getNextLeaf(), values, value);
			}
		}
		return values;
	}

	public List<T> indexHelper(IndexNode node, List<T> values, K key) {
		for (int i = 0; i < node.getNumChildren(); i++) {
			IndexNode temp2 = (IndexNode) node.getChild(i);
			for (int j = 0; j < temp2.getNumKeys(); j++) {
				if (temp2.getKey(i).compareTo(key) >= 0) {
					values.add((T) temp2.getKey(i));
				}
			}
			if (temp2.getNumChildren() > 0) {
				values = indexHelper(temp2, values, key);
			}
		}
		return values;
	}

	/**
	 * Performs a greater than or equal to range search on the B+ tree.
	 * 
	 * If the given key is found in the tree, it returns a list of values with that
	 * key value or less. If the value is not found, it returns a list of all items
	 * with keys less than the given key value. Returned items must be in
	 * **ascending** order by their key field.
	 * 
	 * @param key - The value to perform a <= search against.
	 * @return The values of the items that had a key <= to what was given.
	 */
	public List<T> lessThanEqualToKeySearch(K key) {
		// TODO: Implement me after exactMatch is working (order with greater than
		// doesn't matter)!
		return null;
	}

	/**
	 * Insert a key/value pair into the BPlusTree
	 * 
	 * @param key
	 * @param value
	 */
	public void insert(K key, T value) {
		LeafNode<K, T> newLeaf = new LeafNode<K, T>(key, value, this.degree);
		Entry<K, Node<K, T>> entry = new AbstractMap.SimpleEntry<K, Node<K, T>>(key, newLeaf);

		// Insert entry into subtree with root node pointer
		if (root == null || root.getNumKeys() == 0) {
			root = entry.getValue();
		}

		// newChildEntry null initially, and null on return unless child is
		// split
		Entry<K, Node<K, T>> newChildEntry = getChildEntry(root, entry, null);

		if (newChildEntry == null) {
			return;
		} else {
			IndexNode<K, T> newRoot = new IndexNode<K, T>(newChildEntry.getKey(), root, newChildEntry.getValue(),
					this.degree);
			root = newRoot;
			return;
		}
	}

	private Entry<K, Node<K, T>> getChildEntry(Node<K, T> node, Entry<K, Node<K, T>> entry,
			Entry<K, Node<K, T>> newChildEntry) {
		if (!node.isLeafNode) {
			// Choose subtree, find i such that Ki <= entry's key value < J(i+1)
			IndexNode<K, T> index = (IndexNode<K, T>) node;
			int i = 0;
			while (i < index.getNumKeys()) {
				if (entry.getKey().compareTo(index.getKey(i)) < 0) {
					break;
				}
				i++;
			}
			// Recursively, insert entry
			newChildEntry = getChildEntry((Node<K, T>) index.getChild(i), entry, newChildEntry);

			// Usual case, didn't split child
			if (newChildEntry == null) {
				return null;
			}
			// Split child case, must insert newChildEntry in node
			else {
				int j = 0;
				while (j < index.getNumKeys()) {
					if (newChildEntry.getKey().compareTo(index.getKey(j)) < 0) {
						break;
					}
					j++;
				}

				index.insertSorted(newChildEntry, j);

				// Usual case, put newChildEntry on it, set newChildEntry to
				// null, return
				if (!index.isOverflowed()) {
					return null;
				} else {
					newChildEntry = index.splitNode();

					// Root was just split
					if (index == root) {
						// Create new node and make tree's root-node pointer
						// point to newRoot
						IndexNode<K, T> newRoot = new IndexNode<K, T>(newChildEntry.getKey(), root,
								newChildEntry.getValue(), this.degree);
						root = newRoot;
						return null;
					}
					return newChildEntry;
				}
			}
		}
		// Node pointer is a leaf node
		else {
			LeafNode<K, T> leaf = (LeafNode<K, T>) node;
			LeafNode<K, T> newLeaf = (LeafNode<K, T>) entry.getValue();

			leaf.insertSorted(entry.getKey(), newLeaf.getValue(0));

			// Usual case: leaf has space, put entry and set newChildEntry to
			// null and return
			if (!leaf.isOverflowed()) {
				return null;
			}
			// Once in a while, the leaf is full
			else {
				newChildEntry = leaf.splitNode();
				if (leaf == root) {
					IndexNode<K, T> newRoot = new IndexNode<K, T>(newChildEntry.getKey(), leaf,
							newChildEntry.getValue(), this.degree);
					root = newRoot;
					return null;
				}
				return newChildEntry;
			}
		}
	}

	/**
	 * Delete a key/value pair from this B+Tree
	 * 
	 * @param key
	 */
	public void delete(K key) {
		if (key == null || root == null) {
			return;
		}

		// Check if entry key exist in the leaf node
		Node<K, T> leaf = findLeafNode(root, key);
		if (leaf == null) {
			return;
		}

		// Delete entry from subtree with root node pointer
		Entry<K, Node<K, T>> entry = new AbstractMap.SimpleEntry<K, Node<K, T>>(key, leaf);

		// oldChildEntry null initially, and null upon return unless child
		// deleted
		Entry<K, Node<K, T>> oldChildEntry = root.deleteChildEntry(root, entry, null, root);

		// Readjust the root, no child is deleted
		if (oldChildEntry == null) {
			if (root.getNumKeys() == 0) {
				if (!root.isLeafNode) {
					root = ((IndexNode<K, T>) root).getChild(0);
				}
			}
			return;
		}
		// Child is deleted
		else {
			// Find empty node
			int i = 0;
			K oldKey = oldChildEntry.getKey();
			while (i < root.getNumKeys()) {
				if (oldKey.compareTo(root.getKey(i)) == 0) {
					break;
				}
				i++;
			}
			// Return if empty node already discarded
			if (i == root.getNumKeys()) {
				return;
			}
			// Discard empty node
			root.removeKey(i);
			((IndexNode<K, T>) root).removeChild(i + 1);
			return;
		}
	}
}